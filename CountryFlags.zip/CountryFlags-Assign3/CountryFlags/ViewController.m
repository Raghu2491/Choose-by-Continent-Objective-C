//
//  ViewController.m
//  CountryFlags
//
//  Created by Raghavendra Jayaramegowda on 9/30/15.
//  Copyright © 2015 Raghavendra Jayaramegowda. All rights reserved.
//

#import "ViewController.h"
#import "QuestionsManager.h"
#import <QuartzCore/QuartzCore.h>

@interface ViewController ()<UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *flagImageView;
@property (weak, nonatomic) IBOutlet UITextField *answerTextField;
@property (weak, nonatomic) IBOutlet UIPickerView *answerPicker;
@property (assign, nonatomic) NSInteger currentIndex;

@end

@implementation ViewController {
    CGColorRef _defaultBorderColor;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
    self.answerTextField.rightViewMode = UITextFieldViewModeAlways;
    _defaultBorderColor = self.answerTextField.layer.borderColor;
    [self nextQuestion];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)nextQuestion {
    if (_handledQuestions.count < 1) {
        return;
    }
    
    self.currentIndex = arc4random_uniform((u_int32_t)(_handledQuestions.count - 1));
    [self updateQuestionLayout];
    
    
}

- (void)clearLayout {
    self.flagImageView.image = nil;
    self.answerTextField.text = nil;
    [self clearAnswerIndicating];
    [self.answerTextField resignFirstResponder];
    [self.answerPicker selectRow:0 inComponent:0 animated:NO];
}

- (void)clearAnswerIndicating {
    self.answerTextField.rightView = nil;
    self.answerTextField.layer.borderColor = _defaultBorderColor;
    self.answerTextField.layer.borderWidth = 0.0;
}

- (void)updateQuestionLayout {
    [self clearLayout];
    
    if (self.currentIndex == -1) {
        return;
    }
    
    QuestionModel *question = [_handledQuestions objectAtIndex:self.currentIndex];
    UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"Flags/%@", question.fileName]];
    self.flagImageView.image = image;
    NSLog(@"%@", question.countryName);
}

- (IBAction)didTapOnFlag:(id)sender {
    [self nextQuestion];
}

- (IBAction)didTapBackground:(id)sender {
    [self.answerTextField resignFirstResponder];
    [self checkAnswer];
}

- (void)checkAnswer {
    if (!self.answerTextField.text.length) {
        return;
    }
    
    QuestionModel *currentQuestion = [_handledQuestions objectAtIndex:self.currentIndex];
    
    
    if ([currentQuestion.countryName caseInsensitiveCompare:self.answerTextField.text] == NSOrderedSame) {
        self.answerTextField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Ok"]];
        self.answerTextField.layer.borderColor = [[UIColor greenColor] CGColor];
        
    } else {
        self.answerTextField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Cancel"]];
        self.answerTextField.layer.borderColor = [[UIColor redColor] CGColor];
    }
    self.answerTextField.layer.borderWidth = 1.0;

}

#pragma mark - UIPickerView

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return _handledQuestions.count + 1;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (row == 0) {
        return @"--- Select country ---";
    }
    return [[_handledQuestions objectAtIndex:row - 1] countryName];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    QuestionModel *question = nil;
    if (row > 0) {
        question = [_handledQuestions objectAtIndex:row - 1];
    }
    self.answerTextField.text = question.countryName;
    [self.answerTextField resignFirstResponder];
    [self checkAnswer];
}

#pragma mark - UITextField

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    [self checkAnswer];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    [self clearAnswerIndicating];
    return YES;
}

@end
