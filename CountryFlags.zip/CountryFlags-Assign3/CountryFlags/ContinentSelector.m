//
//  ContinentSelector.m
//  CountryFlags
//
//  Created by Raghavendra Jayaramegowda on 10/19/15.
//  Copyright (c) 2015 Raghavendra Jayaramegowda. All rights reserved.
//

#import "ContinentSelector.h"
#import "QuestionsManager.h"
#import "ViewController.h"

@implementation ContinentSelector

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[[QuestionsManager sharedInstance] continentsList] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString * reuseIdentifier = @"ContinentCell";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:reuseIdentifier];
    }
    cell.textLabel.text = [[QuestionsManager sharedInstance] continentsList][indexPath.row];
    return cell;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSInteger indexOfContinent = [[self tableView] indexPathForCell:sender].row;
    NSString * continent = [[QuestionsManager sharedInstance] continentsList][indexOfContinent];
    ViewController * destinationController = [segue destinationViewController];
    destinationController.handledQuestions = [[[QuestionsManager sharedInstance] continentGroupedQuestions] valueForKey:continent];
}

@end
