﻿//
//  QuestionsManager.m
//  CountryFlags
//
//  Created by Raghavendra Jayaramegowda on 9/30/15.
//  Copyright © 2015 Raghavendra Jayaramegowda. All rights reserved.
//

#import "QuestionsManager.h"

@implementation QuestionModel

- (instancetype)initWithFileName:(NSString *)fileName {
    if (self = [super init]) {
        self.fileName = fileName;
        self.countryName = [QuestionModel extractCountryNameFromFileName:fileName];
        self.continent = [QuestionModel extractContinentNameFromFileName:fileName];
    }
    
    return self;
}

- (NSString *)description {
    return [NSString stringWithFormat:@"%@ --- %@", self.countryName, self.fileName];
}

+ (NSString*)extractCountryNameFromFileName:(NSString*)fileName {
    if (!fileName) {
        return nil;
    }
    
    NSError *error;
    NSRegularExpression *regex = [[NSRegularExpression alloc] initWithPattern:@"-(.*)\\.png" options:0 error:&error];
    if (error) {
        NSLog(@"Error extractCountryNameFromFileName: %@: %@", fileName, error);
        return nil;
    }
    NSTextCheckingResult *checkResult = [regex firstMatchInString:fileName options:0 range:NSMakeRange(0, fileName.length)];
    if (!checkResult) {
        NSLog(@"Cannot extractCountryNameFromFileName: %@", fileName);
        return nil;
    }
    
    NSRange foundRange = [checkResult rangeAtIndex:0];
    if (!foundRange.length) {
        NSLog(@"Range is empty extractCountryNameFromFileName: %@", fileName);
        return nil;
    }
    NSString *foundString = [fileName substringWithRange:NSMakeRange(foundRange.location + 1, foundRange.length - 5)];
    
    return  [[foundString stringByReplacingOccurrencesOfString:@"_" withString:@" "] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
}

+ (NSString *)extractContinentNameFromFileName:(NSString *)fileName {
    if (!fileName) {
        return nil;
    }
    
    NSString *foundString = [[fileName componentsSeparatedByString:@"-"] firstObject];
    if (foundString.length == 0) {
        NSLog(@"Could not extract continentName from file with name: %@", fileName);
        return nil;
    }
    
    return  [[foundString stringByReplacingOccurrencesOfString:@"_" withString:@" "] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
}

@end



@implementation QuestionsManager

+ (instancetype)sharedInstance {
    static QuestionsManager* shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shared = [[QuestionsManager alloc] init];
    });
    
    return shared;
}

- (void)initialSetup {
    [self loadQuestionsData];
    [self groupQuestionsByContinents];
}

- (void)loadQuestionsData {
    NSString * resourcePath = [[NSBundle mainBundle] resourcePath];
    NSString * flagsPath = [resourcePath stringByAppendingPathComponent:@"Flags"];
    NSError * error;
    NSArray * directoryContents = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:flagsPath error:&error];
    
    NSMutableArray *questions = [NSMutableArray array];
    for (NSString *fileName in directoryContents) {
        [questions addObject:[[QuestionModel alloc] initWithFileName:fileName]];
    }
    _questions = [questions sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"countryName" ascending:YES]]];
}

- (void)groupQuestionsByContinents {
    NSMutableDictionary * continentsMap = [NSMutableDictionary new];
    for (QuestionModel * model in _questions) {
        NSString * continent = [model continent];
        NSMutableArray * continentGroup = (NSMutableArray *)[continentsMap valueForKey:continent];
        if (!continentGroup) {
            continentGroup = [NSMutableArray new];
        }
        [continentGroup addObject:model];
        [continentsMap setValue:continentGroup forKey:continent];
    }
    _continentGroupedQuestions = [NSDictionary dictionaryWithDictionary:continentsMap];
    _continentsList = [[continentsMap allKeys] sortedArrayUsingComparator:^NSComparisonResult(NSString * value1, NSString * value2) {
        return [value1 compare:value2];
    }];
}


@end


