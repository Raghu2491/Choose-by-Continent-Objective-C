//
//  QuestionsManager.h
//  CountryFlags
//
//  Created by Raghavendra Jayaramegowda on 9/30/15.
//  Copyright © 2015 Raghavendra Jayaramegowda. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QuestionModel : NSObject

@property (strong, nonatomic) NSString *countryName;
@property (strong, nonatomic) NSString *fileName;
@property (nonatomic, strong) NSString * continent;

- (instancetype)initWithFileName:(NSString*)fileName;

@end

@interface QuestionsManager : NSObject

/// Array of QuestionModel instances
@property (strong, nonatomic, readonly) NSArray *questions;
@property (strong, nonatomic, readonly) NSDictionary *continentGroupedQuestions;
@property (strong, nonatomic, readonly) NSArray * continentsList;

+ (instancetype) sharedInstance;

- (void)initialSetup;

@end

