//
//  ViewController.h
//  CountryFlags
//
//  Created by Raghavendra Jayaramegowda on 9/30/15.
//  Copyright © 2015 Raghavendra Jayaramegowda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) NSArray * handledQuestions;


@end

